package chap7_6.package2;

import chap7_6.package1.A;

public class C {
	public void method() {
		/*
		A a = new A();
		a.field = "value";
		a.method();
		*/
	}
}
