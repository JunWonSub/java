package chap7_6.package2;

import chap7_6.package1.A;

public class D extends A {
	public D() {
		super();
		this.field = "value";
		this.method();
	}
}
