package chap7_4_1;

public class Calculator {	
	double areaCircle(double r) { 
		System.out.println("Calculator ��ü�� areaCircle() ����");
		return 3.14159 * r * r; 
	}
}

