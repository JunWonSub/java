package chap7_7_6;

public class Parent {
}
