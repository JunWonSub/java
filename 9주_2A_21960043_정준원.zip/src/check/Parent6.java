package check;

public class Parent6{
	public String nation;
    
    public Parent6(){
    	this("���ѹα�");
        System.out.println("Parent6() call");
    }
    public Parent6(String nation){
    	this.nation = nation;
        System.out.println("Parent6(String nation) call");
    }
}