package check;

public class ChildExample{
	public static void main(String[] args){
    	Child6 child6 = new Child6();
//    	Parent6(String nation) call
//    	Parent6() call
//    	Child6(String name) call
//    	Child6() call
    }
}