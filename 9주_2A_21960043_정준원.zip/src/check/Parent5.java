package check;

public class Parent5{
	public String name;
    
    public Parent5(String name){
    	this.name = name;
    }
}