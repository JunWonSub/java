package sec06.exam01_protected.package2;

import sec06.exam01_protected.package1.A;

public class C {
	public void method() {
		/*
		A a = new A();
		a.field = "value";
		a.method();
		*/
	}
}
