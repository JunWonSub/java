package verify.exam06;

public class ChildExample {
	public static void main(String[] args) {
		Child child = new Child();
	}
}
