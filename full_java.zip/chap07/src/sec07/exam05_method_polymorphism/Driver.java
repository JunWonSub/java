package sec07.exam05_method_polymorphism;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
