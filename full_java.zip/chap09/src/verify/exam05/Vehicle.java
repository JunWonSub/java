package verify.exam05;

public interface Vehicle {
	public void run();
}
