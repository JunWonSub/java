package verify.exam04;

public class Car {
	class Tire {}
	static class Engine {}
}
