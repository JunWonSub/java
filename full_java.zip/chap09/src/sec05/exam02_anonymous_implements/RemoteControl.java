package sec05.exam02_anonymous_implements;

public interface RemoteControl {
	public void turnOn();
	public void turnOff();
}
