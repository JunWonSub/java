package sec05.exam01_anonymous_extends;

public class Person {
	void wake() {
		System.out.println("7�ÿ� �Ͼ�ϴ�.");
	}
}
