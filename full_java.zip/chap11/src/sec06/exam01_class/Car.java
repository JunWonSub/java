package sec06.exam01_class;

public class Car {
}
