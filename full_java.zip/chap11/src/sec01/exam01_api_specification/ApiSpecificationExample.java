package sec01.exam01_api_specification;

public class ApiSpecificationExample {
	public static void main(String[] args) {
		String name = "ȫ�浿";
		System.out.println(name);
	}
}
