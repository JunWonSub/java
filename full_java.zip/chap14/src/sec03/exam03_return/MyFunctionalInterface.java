package sec03.exam03_return;

@FunctionalInterface
public interface MyFunctionalInterface {
	public int method(int x, int y);
}

