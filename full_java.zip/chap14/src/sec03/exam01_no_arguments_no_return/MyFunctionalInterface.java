package sec03.exam01_no_arguments_no_return;

@FunctionalInterface
public interface MyFunctionalInterface {
    public void method();
}

