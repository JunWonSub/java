package sec03.exam02_arguments;

@FunctionalInterface
public interface MyFunctionalInterface {
    public void method(int x);
}

