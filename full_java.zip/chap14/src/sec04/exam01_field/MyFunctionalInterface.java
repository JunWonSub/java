package sec04.exam01_field;

public interface MyFunctionalInterface {
    public void method();
}

