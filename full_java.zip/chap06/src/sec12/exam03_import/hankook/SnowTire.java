package sec12.exam03_import.hankook;

public class SnowTire { }
