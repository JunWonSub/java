package sec12.exam03_import.kumho;

public class BigWidthTire { }
