package sec07.exam01_constructor_declaration;

public class CarExample {
	public static void main(String[] args) {
		Car myCar = new Car("����", 3000);
		//Car myCar = new Car();  (x)
	}
}
