package sec13.exam01_class_access.package2;

import sec13.exam01_class_access.package1.*;

public class C {
	//A a;
	B b;
}

