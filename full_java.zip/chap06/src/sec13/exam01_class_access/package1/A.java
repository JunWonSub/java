package sec13.exam01_class_access.package1;

class A {

}
