package sec13.exam02_constructor_access.package1;

public class B {
	//�ʵ�
	A a1 = new A(true);
	A a2 = new A(1);
	//A a3 = new A("���ڿ�");
}
