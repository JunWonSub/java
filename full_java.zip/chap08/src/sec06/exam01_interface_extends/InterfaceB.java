package sec06.exam01_interface_extends;

public interface InterfaceB {
	public void methodB();
}

