package sec07.exam02_default_method_extends;

public interface ChildInterface1 extends ParentInterface {
	public void method3();
}

