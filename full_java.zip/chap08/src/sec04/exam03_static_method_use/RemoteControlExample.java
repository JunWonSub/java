package sec04.exam03_static_method_use;

public class RemoteControlExample {
	public static void main(String[] args) {
		RemoteControl.changeBattery();
	}
}
