package sec05.exam02_field_array;

public interface Tire {
	public void roll();
}
