package sec02.exam01_none_generic_type;

public class Box {
	private Object object;
	public void set(Object object) {
		this.object = object;
	}
	public Object get() {
		return object;
	}
}
