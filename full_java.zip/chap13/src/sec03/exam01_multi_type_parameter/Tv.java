package sec03.exam01_multi_type_parameter;

public class Tv {

}
