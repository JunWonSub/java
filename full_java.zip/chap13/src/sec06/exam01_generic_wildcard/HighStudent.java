package sec06.exam01_generic_wildcard;

public class HighStudent extends Student {
	public HighStudent(String name) {
		super(name);
	}
}
