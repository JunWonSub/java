package check;

public class Printer {
	void println(int a) {
		System.out.println(a);
	}
	void println(boolean a) {
		System.out.println(a);
	}
	void println(double a) {
		System.out.println(a);
	}
	void println(String a) {
		System.out.println(a);
	}
}
