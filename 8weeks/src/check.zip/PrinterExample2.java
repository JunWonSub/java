package check;

public class PrinterExample2 {
	public static void main(String[] args) {
		Printer2.println(10);
		Printer2.println(true);
		Printer2.println(5.7);
		Printer2.println("ȫ�浿");
	}
}
