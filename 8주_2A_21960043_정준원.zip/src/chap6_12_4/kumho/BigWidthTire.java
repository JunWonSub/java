package chap6_12_4.kumho;

public class BigWidthTire { }
