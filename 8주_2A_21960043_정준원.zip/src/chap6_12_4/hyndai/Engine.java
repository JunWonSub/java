package chap6_12_4.hyndai;

public class Engine { }
