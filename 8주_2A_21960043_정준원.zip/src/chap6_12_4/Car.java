package chap6_12_4;

import chap6_12_4.hankook.*;
import chap6_12_4.hyndai.*;
import chap6_12_4.kumho.*;

public class Car {
	//�ʵ�
	Engine engine = new Engine();
	SnowTire tire1 = new SnowTire();
	BigWidthTire tire2 = new BigWidthTire();
	chap6_12_4.hankook.Tire tire3 = new chap6_12_4.hankook.Tire();
	chap6_12_4.kumho.Tire tire4 = new chap6_12_4.kumho.Tire();
}
