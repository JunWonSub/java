package chap6_12_4.hankook;

public class SnowTire { }
