package report;

public class Calc {
	static int max(int a, int b) {return a<b?b:a;}
	static int min(int a, int b) {return a<b?a:b;}
}
