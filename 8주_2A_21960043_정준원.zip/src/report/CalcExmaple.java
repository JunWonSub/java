package report;

public class CalcExmaple {
	public static void main(String[] agrs) {
		System.out.println("10�� 8�� �ִ밪 : " + Calc.max(10, 8));
		System.out.println("-3�� -8�� �ּҰ� : " + Calc.min(-3, -8));
	}
}
