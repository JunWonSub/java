package report;

public class SampleClass {
	public int field1;
	int field2;
	private int field3;
}
