package chap6_13_1.p2;

import chap6_13_1.p1.*;

public class C {
	//A a;
	B b;
}

