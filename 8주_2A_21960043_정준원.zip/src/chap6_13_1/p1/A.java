package chap6_13_1.p1;

class A {

}
