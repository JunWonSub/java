package chap6_13_1.p1;

public class B {
	A a;
}

