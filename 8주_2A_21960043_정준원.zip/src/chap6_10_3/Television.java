package chap6_10_3;
public class Television {
    static String company = "Samsung";
    static String model = "LCD";
    static String info;
    
    static {
        info = company + "-" + model;
    }
}
