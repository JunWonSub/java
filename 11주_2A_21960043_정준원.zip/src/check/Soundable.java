package check;

public interface Soundable {
	String sound();
}
