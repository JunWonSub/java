package check;

public interface Action {
	void work();
}
