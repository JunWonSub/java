package chap8_5_4;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
