package chap8_5_6;

public interface Vehicle {
	public void run();
}
