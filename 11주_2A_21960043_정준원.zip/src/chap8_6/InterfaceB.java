package chap8_6;

public interface InterfaceB {
	public void methodB();
}

