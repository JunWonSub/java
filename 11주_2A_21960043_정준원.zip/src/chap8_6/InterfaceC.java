package chap8_6;

public interface InterfaceC extends InterfaceA, InterfaceB {
	public void methodC();
}

