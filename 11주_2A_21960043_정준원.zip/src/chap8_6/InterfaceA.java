package chap8_6;

public interface InterfaceA {
	public void methodA();
}

