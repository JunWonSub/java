package chap8_7_2;

public interface ParentInterface {
    public void method1();
    public default void method2() { /*���๮*/ }
}

