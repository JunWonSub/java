package chap8_7_2;

public interface ChildInterface1 extends ParentInterface {
	public void method3();
}

