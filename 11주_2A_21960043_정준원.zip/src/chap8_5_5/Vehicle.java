package chap8_5_5;

public interface Vehicle {
	public void run();
}
