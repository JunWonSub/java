package chap8_5_2;

public interface Tire {
	public void roll();
}
