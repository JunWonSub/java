package chap8_5_3;

public interface Tire {
	public void roll();
}
